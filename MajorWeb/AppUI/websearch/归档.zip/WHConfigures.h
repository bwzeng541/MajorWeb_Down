//
//  WHConfigures.h
//  UrlWebViewForIpad
//
//  Created by Meng Xiangping on 1/9/13.
//
//

#import <Foundation/Foundation.h>

@interface WHConfigures : NSObject

+ (NSString *) baiduSearchLink:(NSString *) keyword;

@end
